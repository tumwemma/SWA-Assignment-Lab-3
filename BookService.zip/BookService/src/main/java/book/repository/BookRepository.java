package book.repository;



import org.springframework.data.mongodb.repository.MongoRepository;

import book.domain.Book;


public interface BookRepository extends MongoRepository<Book, String> {

}
